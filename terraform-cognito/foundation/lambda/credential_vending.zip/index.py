import json
import os
import boto3
import urllib.request
import base64
from datetime import datetime

# Cache for JWKS
_jwks_cache = None

def get_jwks(issuer_url):
    """Fetch JWKS from Cognito."""
    global _jwks_cache
    if _jwks_cache:
        return _jwks_cache

    jwks_url = f"{issuer_url}/.well-known/jwks.json"
    with urllib.request.urlopen(jwks_url, timeout=5) as response:
        _jwks_cache = json.loads(response.read().decode())
    return _jwks_cache

def decode_jwt_unverified(token):
    """Decode JWT without verification (verification done by checking claims)."""
    parts = token.split('.')
    if len(parts) != 3:
        raise ValueError("Invalid JWT format")

    # Decode header and payload
    def b64_decode(data):
        # Add padding if needed
        padding = 4 - len(data) % 4
        if padding != 4:
            data += '=' * padding
        return base64.urlsafe_b64decode(data)

    header = json.loads(b64_decode(parts[0]))
    payload = json.loads(b64_decode(parts[1]))
    return header, payload

def validate_token(token, expected_issuer):
    """
    Validate the Cognito access token.

    For production, you should use a proper JWT library with signature verification.
    This implementation validates claims but relies on HTTPS for transport security.
    """
    try:
        header, payload = decode_jwt_unverified(token)
    except Exception as e:
        return None, f"Invalid token format: {e}"

    # Validate issuer
    if payload.get('iss') != expected_issuer:
        return None, f"Invalid issuer: {payload.get('iss')}"

    # Validate token_use (must be 'access' for M2M tokens)
    if payload.get('token_use') != 'access':
        return None, f"Invalid token_use: {payload.get('token_use')}"

    # Validate expiration
    exp = payload.get('exp', 0)
    if datetime.utcnow().timestamp() > exp:
        return None, "Token expired"

    return payload, None

def handler(event, context):
    """
    Lambda handler for credential vending.

    Expected request body:
    {
        "access_token": "eyJ..."
    }

    Returns:
    {
        "credentials": {
            "access_key_id": "...",
            "secret_access_key": "...",
            "session_token": "...",
            "expiration": "2024-01-01T00:00:00Z"
        },
        "s3_bucket": "...",
        "s3_path_prefix": "...",
        "aws_region": "..."
    }
    """
    print(f"Event: {json.dumps(event)}")

    # Configuration from environment
    issuer = os.environ['COGNITO_ISSUER']
    table_name = os.environ['DYNAMODB_TABLE']
    aws_region = os.environ['AWS_REGION']
    s3_bucket = os.environ['S3_BUCKET']

    # Parse request body
    try:
        if event.get('body'):
            body = json.loads(event['body']) if isinstance(event['body'], str) else event['body']
        else:
            body = event
        access_token = body.get('access_token')
        if not access_token:
            return response(400, {'error': 'Missing access_token'})
    except json.JSONDecodeError as e:
        return response(400, {'error': f'Invalid JSON: {e}'})

    # Validate the access token
    claims, error = validate_token(access_token, issuer)
    if error:
        print(f"Token validation failed: {error}")
        return response(401, {'error': error})

    client_id = claims.get('client_id') or claims.get('sub')
    scopes = claims.get('scope', '').split()
    print(f"Client ID: {client_id}, Scopes: {scopes}")

    # Look up the role ARN for this client
    dynamodb = boto3.resource('dynamodb')
    table = dynamodb.Table(table_name)

    try:
        result = table.get_item(Key={'client_id': client_id})
        if 'Item' not in result:
            print(f"No role mapping found for client: {client_id}")
            return response(403, {'error': 'Client not authorized'})

        item = result['Item']
        role_arn = item['role_arn']
        s3_path_prefix = item['s3_path_prefix']
        allowed_scopes = item.get('allowed_scopes', [])

        print(f"Found mapping: role={role_arn}, prefix={s3_path_prefix}")
    except Exception as e:
        print(f"DynamoDB error: {e}")
        return response(500, {'error': 'Internal error looking up client'})

    # Assume the role
    sts = boto3.client('sts')
    try:
        assume_response = sts.assume_role(
            RoleArn=role_arn,
            RoleSessionName=f"cognito-{client_id[:8]}",
            DurationSeconds=3600,  # 1 hour
        )

        creds = assume_response['Credentials']

        return response(200, {
            'credentials': {
                'access_key_id': creds['AccessKeyId'],
                'secret_access_key': creds['SecretAccessKey'],
                'session_token': creds['SessionToken'],
                'expiration': creds['Expiration'].isoformat()
            },
            's3_bucket': s3_bucket,
            's3_path_prefix': s3_path_prefix,
            'aws_region': aws_region
        })
    except Exception as e:
        print(f"STS AssumeRole error: {e}")
        return response(500, {'error': f'Failed to assume role: {e}'})

def response(status_code, body):
    """Build API Gateway response."""
    return {
        'statusCode': status_code,
        'headers': {
            'Content-Type': 'application/json',
            'Access-Control-Allow-Origin': '*'
        },
        'body': json.dumps(body, default=str)
    }
