export const handler = async (event, context) => {
  // Add 'aud' claim to access tokens for M2M client credentials flow
  // This is required for AWS STS AssumeRoleWithWebIdentity
  //
  // The aud claim must match the OIDC provider's client_id_list,
  // which is configured with the resource server identifier.
  // We also add 'client_id' claim for IAM trust policy conditions.
  const resourceServerId = process.env.RESOURCE_SERVER_ID;

  event.response = {
    claimsAndScopeOverrideDetails: {
      accessTokenGeneration: {
        claimsToAddOrOverride: {
          // aud must match OIDC provider's client_id_list
          aud: resourceServerId,
          // client_id for IAM trust policy StringEquals conditions
          client_id: event.callerContext.clientId
        }
      }
    }
  };

  return event;
};
